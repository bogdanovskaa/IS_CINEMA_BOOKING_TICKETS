﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace OnlineMovieTicketBooking.Models.ViewModels
{
    public class StackedViewModel
    {
        public string DimensionOne { get; set; }
        public int Quantity { get; set; }
    }
}
